Mein Haushaltsbuch – Version 4.2
Reihenfolge: Diagramm, Plus/Minus-Schnellerfassung, Gesamtkontostand.
